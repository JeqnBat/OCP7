  JB PELLIER . OCP7 . Soutenance 06/05/2020


 WampServer, easyPHP ou autre pour ex�cuter l'appli en local :
 	
 ->	ex: http://127.0.0.1/OCP7/



 Board & commits du projet sur github :

 ->	https://github.com/JeqnBat/OCP7